/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sakibul.diagnosticmanagementsystem.reportmodel;

/**
 *
 * @author sakib
 */
public class TestPresReport {
    String presid;

    public String getPresid() {
        return presid;
    }

    public void setPresid(String presid) {
        this.presid = presid;
    }
    
}
