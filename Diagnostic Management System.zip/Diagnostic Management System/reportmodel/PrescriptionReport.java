/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sakibul.diagnosticmanagementsystem.reportmodel;

/**
 *
 * @author sakib
 */
public class PrescriptionReport {
    
    String pid;
    
    int presid;

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public int getPresid() {
        return presid;
    }

    public void setPresid(int presid) {
        this.presid = presid;
    }
    
    
    
    
}
