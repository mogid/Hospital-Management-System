/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital;

import java.sql.*;

/**
 *
 * @author User
 */
public class DBConnection  {

    public static Connection getConnection() {
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/nikrailhospital", "root", "123");
        } catch (Exception e) {
        }
        return con;
    }
}


